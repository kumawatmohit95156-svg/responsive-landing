# Nova Responsive Landing Page

A responsive creative-studio landing page built with semantic HTML, CSS, and vanilla JavaScript.

## Files
- `index.html` — page structure and content
- `styles.css` — responsive layout, colors, typography, and visual styles
- `script.js` — mobile navigation toggle and dynamic footer year
- `REPORT.docx` — internship task report

## Run locally
Open `index.html` in a modern browser. The page uses Google Fonts when an internet connection is available; system sans-serif fallbacks are included.

## Features
- Responsive desktop, tablet, and mobile layouts
- Mobile navigation menu with `aria-expanded` state
- Work, services, about, and contact sections
- Semantic landmarks, descriptive links, and reduced-motion support
- CSS-created artwork and project mockups (no image assets required)

## GitHub
Create a repository on your GitHub account, upload these project files, and paste that repository's URL into the internship submission form. The authoring environment cannot publish to your GitHub account.
